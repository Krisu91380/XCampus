import fs from 'fs';
import path from 'path';

export interface PaymentSettings {
  isEnabled: boolean;
  receiverName: string;
  upiId?: string;
  qrImageUrl: string;
  instructions: string;
  updatedAt: string;
  updatedBy?: string;
}

const SETTINGS_FILE = path.join(process.cwd(), 'prisma', 'payment_settings.json');

const DEFAULT_SETTINGS: PaymentSettings = {
  isEnabled: true,
  receiverName: 'KRISH SO ANIL KUMAR',
  upiId: '',
  qrImageUrl: '/uploads/payment/custom_qr.png',
  instructions:
    '1. Scan the QR code using any UPI app (PhonePe, Google Pay, Paytm, BHIM).\n2. Pay the exact package amount shown above.\n3. Copy the 12-digit UTR / Transaction Reference Number from your payment app.\n4. Submit the reference number below for instant administrative verification.',
  updatedAt: new Date().toISOString(),
};

export function getPaymentSettings(): PaymentSettings {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      const data = fs.readFileSync(SETTINGS_FILE, 'utf-8');
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    }
  } catch (err) {
    console.error('Error reading payment settings:', err);
  }
  return DEFAULT_SETTINGS;
}

export function savePaymentSettings(settings: Partial<PaymentSettings>, updatedBy?: string): PaymentSettings {
  const current = getPaymentSettings();
  const updated: PaymentSettings = {
    ...current,
    ...settings,
    updatedAt: new Date().toISOString(),
    updatedBy: updatedBy || current.updatedBy,
  };

  try {
    const dir = path.dirname(SETTINGS_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(updated, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving payment settings to disk:', err);
  }

  return updated;
}
